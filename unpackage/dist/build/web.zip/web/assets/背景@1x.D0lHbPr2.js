const s="/course-selection/assets/%E8%83%8C%E6%99%AF@1x-CaebryiA.png";export{s as _};
