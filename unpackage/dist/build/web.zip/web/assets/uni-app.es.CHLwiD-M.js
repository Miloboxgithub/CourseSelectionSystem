import{y as s,z as a,A as o,O as r}from"./index-CL0tpXlb.js";const t=(r=>(t,e=o())=>{!s&&a(r,t,e)})(r);export{t as o};
